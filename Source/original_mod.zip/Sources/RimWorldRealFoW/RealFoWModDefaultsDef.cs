﻿using System;
using Verse;

namespace RimWorldRealFoW
{
	// Token: 0x02000002 RID: 2
	public class RealFoWModDefaultsDef : Def
	{
		// Token: 0x04000001 RID: 1
		public static readonly string DEFAULT_DEF_NAME = "RealFoWModDefaults";

		// Token: 0x04000002 RID: 2
		public float baseViewRange = 32f;


	}
}
